deltaViz
========

deltaViz self service dashboard extension for Qlik Sense

Under terms of use and licence : [LICENCE](https://github.com/yblake/deltaViz/blob/master/LICENSE)

See demonstration video : [Build your own executive dashboard in 1 mn with Qlik Sense](http://youtu.be/4s30AEf4qJc).

Installation :
==============
For Qlik Sense desktop installation, copy all files in extensions folder (i.e.  C:\Users\<username>\Documents\Qlik\Sense\Extensions).